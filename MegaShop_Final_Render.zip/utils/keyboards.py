# Keyboards
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def lang_keyboard():
    kb = InlineKeyboardMarkup(row_width=3)
    kb.add(
        InlineKeyboardButton("🇪🇬 العربية", callback_data='lang_ar'),
        InlineKeyboardButton("🇬🇧 English", callback_data='lang_en'),
        InlineKeyboardButton("🇮🇷 فارسی", callback_data='lang_fa')
    )
    return kb
