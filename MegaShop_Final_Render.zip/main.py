# MegaShop Bot Main
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor
from utils import helpers, keyboards
import json

TOKEN = "7451031714:AAGnOlMsUUMsNQ1Kyjoa0qEbRflAmhbT4y8"
ADMIN_IDS = [6534780281]

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    await message.answer("اختر لغتك / Choose your language / زبان خود را انتخاب کنید", reply_markup=keyboards.lang_keyboard())

if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=True)
